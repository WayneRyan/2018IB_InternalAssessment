import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Poloniex implements Serializable{
	private PoloniexUtil util;

	public Poloniex() {
		util = new PoloniexUtil();
	}

	public Double[] getPrice(String coin, int resolution, long start, long end) {
		/*(int resTime = 300;
		switch (resolution) {
		case 1:
			resTime = 300; break;
		case 2:
			resTime = 900; break;
		case 3:
			resTime = 1800; break;
		case 4:
			resTime = 14400; break;
		case 5:
			resTime = 86400; break;
		}
	*/
		String url = "https://poloniex.com/public?command=returnChartData&currencyPair=" + coin + "&start=" + start
				+ "&end=" + end + "&period=" + resolution;
		
		System.out.println(url);
		System.out.println(PoloniexUtil.getHTML(url));
		
		JSONArray jArr = PoloniexUtil.getJsonArray(url);
		Double[] ret = new Double[jArr.length()];
		for (int i = 0; i < jArr.length(); i++) {
			double price = jArr.getJSONObject(i).getDouble("open");
			ret[i] = price;
		}
		return ret;
	}
	
	
	public Long[] getDates(String coin, int resolution, long start, long end) {
		
		//TODO: clean up with getPrice()
		/*
		int resTime = 300;
		switch (resolution) {
		case 1:
			resTime = 300; break;
		case 2:
			resTime = 900; break;
		case 3:
			resTime = 1800; break;
		case 4:
			resTime = 14400; break;
		case 5:
			resTime = 86400; break;
		}
		 */
		String url = "https://poloniex.com/public?command=returnChartData&currencyPair=" + coin + "&start=" + start
				+ "&end=" + end + "&period=" + resolution;
		JSONArray jArr = PoloniexUtil.getJsonArray(url);
		Long[] ret = new Long[jArr.length()];	
		for (int i = 0; i < jArr.length(); i++) {
			long date = jArr.getJSONObject(i).getLong("date");
			ret[i] = date;
		}
		return ret;
	}

	private int getTime24Hr() {
		Date d = new Date();
		long time = d.getTime() / 1000;
		return (int) (time - 86400);
	}

	private int getTime() {
		Date d = new Date();
		return (int) (d.getTime() / 1000);
	}

	public Double[] getPrice24Hr(String coin, int resolution) {
		int start = getTime24Hr();
		int end = getTime();
		return getPrice(coin, resolution, start, end);
	}

	public double getCurrPrice(String coin) {
		JSONObject json = PoloniexUtil.getJsonObject("https://poloniex.com/public?command=returnTicker");
		JSONObject subJ = json.getJSONObject(coin);
		return subJ.getDouble("last");

	}
	
	public static String[] getMarkets(){
		JSONObject json = PoloniexUtil.getJsonObject("https://poloniex.com/public?command=returnTicker");
		List<Object> s = json.names().toList();
		Object[] r = s.toArray();
		String[] ret = new String[r.length];
		for(int i = 0; i < r.length; i++) {
			ret[i] = r[i].toString();
		}
		//Alphabetize 
		ArrayList<String> retList = new ArrayList<String>();
		for (String string : ret) {
			retList.add(string);
		}
		Collections.sort(retList);
		for (int i = 0; i < ret.length; i++) {
			String string = retList.get(i);
			ret[i] = string;
		}
		return ret;
	}

	
}

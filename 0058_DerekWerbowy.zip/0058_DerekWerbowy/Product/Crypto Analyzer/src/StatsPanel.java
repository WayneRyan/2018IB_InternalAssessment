import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class StatsPanel extends JPanel{
	private JLabel buys;
	private JLabel buyVal;
	
	private JLabel sells;
	private JLabel sellVal;
	
	private JLabel profitLoss;
	private JLabel pLVal;
	
	private static final long serialVersionUID = 1L;
	
	public StatsPanel() {
		this.setLayout(new GridLayout(0, 3));
		this.setBorder(BorderFactory.createTitledBorder("Stats"));


		buys = new JLabel("Buys:");
		this.add(buys);

		buyVal = new JLabel();
		this.add(buyVal);
		
		profitLoss = new JLabel("Profit/Loss:");
		this.add(profitLoss);

		sells = new JLabel("Sales:");
		this.add(sells);

		sellVal = new JLabel();
		this.add(sellVal);
		
		pLVal = new JLabel();
		this.add(pLVal);
		
		
		
	}
	
	

}

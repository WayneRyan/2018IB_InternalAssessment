import java.awt.AWTEvent;
import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;


public class Simulator{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String DATA_FILE = "polo_data.tmp";
	private static final String DATE_ARGS = "1,3,7";
	private static Process proc;
	private HashMap<Long, Double> data;
	private ArrayList<Date> dates;
	private ArrayList<Double> prices;
	//private File f;
	private String dataCoinArg;
	private Coin coin;
	private long startDate;
	private long endDate;
	private ArrayList<Double> simData;
	private ArrayList<Long> simDate;
	private String dataLocation;
	public Simulator(File f, Coin coin, Coin[] compareCoin) throws IOException, InterruptedException {
		System.out.println("Coin: "+coin.getName());
		System.out.println("Pred #1: "+compareCoin[0]);
		dataLocation = new File(Exporter.PATH).getAbsolutePath();
		System.out.println("TMP file location: "+dataLocation);
		simData = new ArrayList<Double>();
		simDate = new ArrayList<Long>();
		//this.f = f;
		this.coin = coin;
		data = coin.getData();
		convertData();
		
		//Export all coins, including to analyze
		Coin[] allCoins = new Coin[compareCoin.length+1];
		allCoins[0] = coin;
		for (int i = 1; i < compareCoin.length+1; i++)
			allCoins[i] = compareCoin[i-1];
		System.out.println("Start date: "+allCoins[0].getDates()[0]);
		System.out.println("End date: "+allCoins[0].getDates()[allCoins[0].getDates().length-1]);
		
		
		//Check to make sure array size is consistent across coins
//		int lowestDateSize = allCoins[0].getDates().length;
//		int lowestPriceSize = allCoins[0].getPrices().length;
//		boolean equal = true;
//		if (lowestDateSize != lowestPriceSize) equal = false;
//		for (int i = 1; i < allCoins.length; i++) { //i = 0?
//			Coin c = allCoins[i];
//			int currDateSize = c.getDates().length;
//			int currPriceSize = c.getPrices().length;
//			if (currDateSize != currPriceSize) {
//				System.err.println("Unequal array sizes");
//				//Trim 
//				if (currDateSize > currPriceSize) {
//					//Trim date array down to price array's size
//					System.out.println("Trimming "+c.getName()+" date array from "+currDateSize+" to "+currPriceSize);
//					trimDateArr(c, currPriceSize);
//				} else {
//					//Trim price array down to date array's size
//					System.out.println("Trimming "+c.getName()+" price array from "+currPriceSize+" to "+currDateSize);
//					trimPriceArr(c, currDateSize);
//				}
//				equal = false;
//			}
//			if (currDateSize != lowestDateSize) {
//				if (currDateSize < lowestDateSize) {
//					lowestDateSize = currDateSize;
//				}
//				equal = false;
//			}
//		}
		//Determine if any coin's arrays are larger than any other coins'
		int smallestArrSize = allCoins[0].getDates().length; //.getDates() and .getPrices() should be equal by this point
		for (int i = 1; i < allCoins.length; i++) {
			Coin c = allCoins[i];
			int arrSize = c.getDates().length;
			if (arrSize < smallestArrSize) 
				smallestArrSize = arrSize;
		}
		for (Coin c : allCoins) {
			int arrSize = c.getDates().length;
			if (arrSize > smallestArrSize) {
				//Trim the coin data to match the size of the smallest coin's data
				System.out.println("Trimming all arrays on "+c.getName()+" to "+smallestArrSize);
				trimDateArr(c, smallestArrSize);
				trimPriceArr(c, smallestArrSize);
			}
		}
//		if (!equal) {
//			System.err.println("Mismatched Arrays");
//			//Trim the longest coin
//			//return;
//		}
		/*System.out.println("Exporting coin list: ");
		for (Coin c : allCoins)
			System.out.println(c.getName());
		Exporter ex = new Exporter();
		ex.export(allCoins);
		
		debugFile();*/
		
		//Convert compareCoin list to string for jar argument
		dataCoinArg = "";
		for (Coin c : compareCoin){
			dataCoinArg += c.getName()+" ";
		}
		dataCoinArg.trim();
		
		ProcessBuilder pb = new ProcessBuilder("java", "-jar", "\""+f.getAbsolutePath()+"\"");
		String cwd = System.getProperty("user.home");
		pb.directory(new File(System.getProperty("user.home")));
		System.out.println("Cwd: "+cwd);
		

		Exporter ex = new Exporter();
		ex.export(allCoins); //Export coin list, then pass start/end date args to function program
		
		//For right now we will run predictor with 10% chunks
		double chunkPercent = 0.10;
		int resolution = 1; //Move predictor function x indexes per iteration
		int arraySize = allCoins[0].getDates().length; //Will be equal throughout all coins/data
		int chunkSize = (int)(chunkPercent*arraySize);
		int dateStartIndex = 0;
		int dateEndIndex = dateStartIndex+chunkSize;
		
		debugFile();
		System.out.println("**Simulating**");	
		System.out.println("Chunk size: "+chunkSize);
		System.out.println("Start index: "+dateStartIndex);
		System.out.println("End index: "+dateEndIndex);
		long periodTime = allCoins[0].getDates()[1] - allCoins[0].getDates()[0]; //Used for simDate
		int pass = 0;
		while (dateEndIndex < arraySize) {
			Long [] dateArr = allCoins[0].getDates();
			long dateStart = dateArr[dateStartIndex];
			long dateEnd = dateArr[dateEndIndex];

			//System.out.println("Chunk start: "+dateStart+" @ index "+(dateStartIndex));
			//System.out.println("Chunk end: "+dateEnd+" @ index "+(dateEndIndex));
			/*for (int i = dateStartIndex; i < dateEndIndex; i++) {
				System.out.println("Price @ index "+i+": "+allCoins[0].getPrices()[i]);
			}*/
			System.out.println("Pass #"+pass);
			pass++;
			Double simRet = simulate(dateStart, dateEnd);
			if (simRet != null) {
				simData.add(simRet);
				simDate.add(dateEnd+periodTime);
			}
			else 
				throw new IOException();
			dateStartIndex += resolution;
			dateEndIndex += resolution;
			//break; //Temporary hotfix
		}
		System.out.println("Simulator data: ");
		for (int i = 0; i < simData.size(); i++) {
			System.out.println(simData.get(i)+", "+simDate.get(i));
		}
		
	
		
	}
	
	private double simulate(long start, long end) throws IOException, InterruptedException {
		Double ret = null;
		
	
		dataCoinArg.trim();
		String command = "java -jar "+"\""+"predFunc.jar"+"\""+" "+DATA_FILE+" "+DATE_ARGS+" "+coin.getName()+" "+dataCoinArg+" "+start+" "+end;
		//System.out.println("Running '"+command+"'...");
		Runtime.getRuntime();
		proc = Runtime.getRuntime().exec(command);	
		proc.waitFor();
		
		//Input stream
		InputStream in = proc.getInputStream();
		byte[] b = new byte[in.available()];
		in.read(b, 0, b.length);
		System.out.print("[Simulator] ");
		String inString = new String(b);
		System.out.println(inString);
		ret = null;
		try {
			ret = new Double(inString);
		} catch (NumberFormatException e) {
			System.err.println("Error while reading simulator output");
			throw new IOException();
		}
		//Error stream
		InputStream err = proc.getErrorStream();
		byte[] c = new byte[err.available()];
		err.read(c, 0, c.length);
		if (c.length > 0) {
			System.err.println("[Simulator Error]");
			System.err.println(new String(c));
			
			//TODO: raise exception and display in GUI
			return 0.0;
		}
		
		//If no errors occur, return the double array
		return ret;

	}
	
	private void convertData(){
		dates = new ArrayList<Date>();
		prices = new ArrayList<Double>();
		//Iterate through hashmap and get the date/prices
		ArrayList<Long> keys = new ArrayList<Long>();
		keys.addAll(data.keySet());
		Collections.sort(keys);
		Iterator<Long> it = keys.iterator();
		while (it.hasNext()) {
			Long key = it.next();
			dates.add(new Date((Long)key*1000)); //Convert from timestamp to date
			prices.add((Double)data.get(key));
		}
	}
	
	private void debugFile() {
		try {
			FileInputStream fis = new FileInputStream(Exporter.PATH);
			System.out.println();
			ObjectInputStream ois = new ObjectInputStream(fis);
			Coin[] ret = (Coin[])ois.readObject();
			fis.close();
			ois.close();
			
			Coin[] c = ret;
			System.out.println("**Coin Data File Debug**");
			for (int i = 0; i < c.length; i++) {
				System.out.println("Coin "+c[i].getName()+" ("+c[i].getData().size()+")");
				for (int j = 0; j < c[i].getDates().length; j++) {
					System.out.println("Index "+j+": ");
					System.out.println("Date = "+c[i].getDates()[j]+" Price = "+c[i].getPrices()[j]);
				}
			}
			System.out.println("Number of coins: "+c.length);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//In case of poloniex returning a larger price array 
	private void trimPriceArr(Coin c, int size) {
		Double[] currPriceArr = c.getPrices();
		Double[] trimmedPriceArr = new Double[size];
		for (int i = 0; i < size; i++) 
			trimmedPriceArr[i] = currPriceArr[i];
		c.setPrices(trimmedPriceArr);
	}
	
	private void trimDateArr(Coin c, int size) {
		Long[] currDateArr = c.getDates();
		Long[] trimmedDateArr = new Long[size];
		for (int i = 0; i < size; i++) 
			trimmedDateArr[i] = currDateArr[i];
		c.setDates(trimmedDateArr);
	}
	
	public double[] getSimData(){
		double[] ret = new double[simData.size()];
		for (int i = 0; i < simData.size(); i++) 
			ret[i] = simData.get(i);	
		return ret;
	}
	
	public long[] getSimDate() {
		long[] ret = new long[simDate.size()];
		for (int i = 0; i < simDate.size(); i++)
			ret[i] = simDate.get(i);
		return ret;
	}
}



//System.out.println("Original file length: "+);
//while (dateEnd >= 0){
//	//While the end index is greater than 0
//	//Export polo data file between start and end indexes for all coins
//	int exportArrIndex = 0; //Keep track of where trimmed coins show go in export array
//	for (Coin c : allCoins){ //Add +1?		
//		System.out.println("Currently trimming "+c.getName());
//		Long[] originalDates = c.getDates();
//		Double[] originalPrices = c.getPrices();
//		Long[] exportDates = new Long[dateStart-dateEnd];
//		Double[] exportPrices = new Double[dateStart-dateEnd];
//		
//		int dataIndex = 0;
//		for (int i = dateStart-1; i >= dateEnd; i--) {
//			System.out.println("Adding index "+i);
//			//Trim dates and prices to within index range
//			exportDates[dataIndex] = originalDates[i];
//			exportPrices[dataIndex] = originalPrices[i];
//			dataIndex++;
//		}
//		//Make new coin from trimmed data
//		Coin exportCoin = new Coin(c.getName());
//		exportCoin.setDates(exportDates);
//		exportCoin.setPrices(exportPrices);				
//		exportCoin.pushParameters();
//		System.out.println("Created new coin with data length of "+dataIndex);
//		System.out.println("Coin dates: ");
//		for (Long l : exportCoin.getDates()) System.out.println(l);
//		System.out.println("Coin prices: ");
//		for (Double d : exportCoin.getPrices()) System.out.println(d);
//		//Put in export array
//		toExport[exportArrIndex] = exportCoin;		
//		exportArrIndex++;
//	}
//	System.out.println("Exporting ");
//	for (Coin c : toExport) System.out.println(c.getName());
//	//Export list
//	ex.export(toExport);
//	//Simulate
//	//simulate();
//	dateStart -= move;
//	dateEnd -= move;
//	break;
//	//TODO: wrap up remaining numbers
//}




import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;

public class FunctionPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	
	private JFileChooser chooseFile;
	private JButton fileButton;
	private File selectedFile;
	
	private GridBagConstraints c;
	public FunctionPanel() {
		
		c = new GridBagConstraints();
		this.setLayout(new GridBagLayout());
		this.setBorder(BorderFactory.createTitledBorder("Function"));
		this.setMinimumSize(new Dimension(100, 100));
		
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.weightx = .5;
		c.weighty = .5;
		c.ipadx = 10;
		c.ipady = 10;
		c.insets = new Insets(5,5,5,5);
		//c.anchor = GridBagConstraints.CENTER;
		c.fill = GridBagConstraints.BOTH;
		fileButton = new JButton("Choose File...");
		fileButton.addActionListener(this);
		this.add(fileButton, c);
		
		chooseFile = new JFileChooser();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		int ret = chooseFile.showOpenDialog(this);
		if (ret == JFileChooser.APPROVE_OPTION) {
			selectedFile = chooseFile.getSelectedFile();
			System.out.println(selectedFile.getAbsolutePath());
			
			//Copy into jar
			try {
			copyFileUsingStream(selectedFile, new File("predFunc.jar"));
			System.out.println("Copied jar file to cwd");
			} catch (IOException ioE){
				ioE.printStackTrace();
			}
		} else if (ret == JFileChooser.ERROR_OPTION) {
			//todo: error
		}
		
	}
	
	public File getSelectedFile(){
		return selectedFile;
	}
	
	private static void copyFileUsingStream(File source, File dest) throws IOException {
	    InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}

}

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import org.knowm.xchart.XChartPanel;
import org.knowm.xchart.XYChart;
import org.knowm.xchart.XYChartBuilder;
import org.knowm.xchart.XYSeries;
import org.knowm.xchart.style.markers.SeriesMarkers;


public class Chart {
	private XYChart chart;
	private HashMap<Long, Double> data;
	private JPanel panel;
	private XYSeries coinSeries;
	public Chart() {
		
		XYChart chart = new XYChartBuilder().title("Crypto Analyzer").build();
		
		this.chart = chart;
		panel = new XChartPanel(chart);
		panel.setBorder(BorderFactory.createTitledBorder("Graph"));

		
	}
	
	public JPanel getChart() {
		return panel;
	}
	
	public void addData(HashMap<Long, Double> data, String name) {
		this.data = data;
		ArrayList<Date> dates = new ArrayList<Date>();
		ArrayList<Double> prices = new ArrayList<Double>();
		//Iterate through hashmap and get the date/prices
		ArrayList<Long> keys = new ArrayList<Long>();
		keys.addAll(data.keySet());
		Collections.sort(keys);
		Iterator<Long> it = keys.iterator();
		while (it.hasNext()) {
			Long key = it.next();
			dates.add(new Date((Long)key*1000)); //Convert from timestamp to date
			prices.add((Double)data.get(key));
		}
		coinSeries = chart.addSeries(name, dates, prices);
		coinSeries.setMarker(SeriesMarkers.NONE);
		coinSeries.setShowInLegend(false);
		panel.repaint();
	}
	
	public void addPredData(double[] simData, long[] simDates) {
		ArrayList<Date> dates = new ArrayList<Date>();
		ArrayList<Double> prices = new ArrayList<Double>();
		double[] coinPrices = coinSeries.getYData();
		
		for (long i : simDates) 
			dates.add(new Date(i*1000));
		for (int i = 0; i < simData.length; i++) {
			prices.add(simData[i]*coinPrices[i]);
		}
		XYSeries series = chart.addSeries("Predictor", dates, prices);
		series.setMarker(SeriesMarkers.NONE);
		series.setLineColor(Color.BLACK);
	}
	public void setTitle(String title) {
		chart.setTitle(title);
	}
	public String getTitle(){
		return chart.getTitle();
	}
	
	public void clearData() {
		chart.removeSeries("Test");
		panel.repaint();
	}
	
}

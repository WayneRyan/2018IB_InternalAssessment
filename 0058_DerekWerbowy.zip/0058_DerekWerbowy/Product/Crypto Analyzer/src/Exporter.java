import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Exporter {
	public static final String PATH = /* System.getProperty("user.home")+ */"polo_data.tmp";

	public void export(Coin[] coin) {
		try {
			File f = new File(PATH);
			if (f.exists()) {
				// Non clean shutdown, delete it
				f.delete();
			}
			System.out.println("Writing coin list to " + f.getAbsolutePath());
			f.createNewFile();
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(coin);
			oos.close();
			fos.close();
			System.out.println("Done");
		} catch (IOException e) {
			System.out.println("Error exporting data");
			e.printStackTrace();
		}
	}
}

import java.io.Serializable;
import java.util.HashMap;


public class Coin implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private HashMap<Long, Double> data;
	private Poloniex p;
	private Long[] dates;
	private Double[] prices;
	public Coin(String name) {
		//Dates and prices must be same length
		this.name = name;
		p = new Poloniex();
		
	}
	
	public String getName() {
		return name;
		
	}
	
	public void setParameters(int resolution, long start, long end) {
		
		Long[] dates = p.getDates(name, resolution, start, end);
		System.out.println("Date array length: "+dates.length);
		Double[] prices  = p.getPrice(name, resolution, start, end);
		this.dates = dates;
		this.prices = prices;
		data = new HashMap<Long, Double>();
		for (int i = 0; i < prices.length; i ++) {
			data.put(dates[i], prices[i]);
		}		
	}
	
	public void pushParameters() {
		data = new HashMap<Long, Double>();
		for (int i = 0; i < prices.length; i ++) {
			data.put(dates[i], prices[i]);
		}	
	}
	public HashMap<Long, Double> getData() {
		return data;
	}
	
	public Long[] getDates() {
		return dates;
	}
	
	public void setDates(Long[] dateArr) {
		dates = dateArr;
	}
	
	public Double[] getPrices() {
		return prices;
	}
	
	public void setPrices(Double[] priceArr) {
		prices = priceArr;
	}
	public String toString(){
		String ret = "[";
		for (int i = 0; i < dates.length; i++) {
			ret += dates[i] + ", " + prices[i];
		}
		ret += "]";
		return ret;
	}
}

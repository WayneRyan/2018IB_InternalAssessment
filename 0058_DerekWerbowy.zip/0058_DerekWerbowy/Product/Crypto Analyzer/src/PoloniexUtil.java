import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class PoloniexUtil implements Serializable{
	public static String getHTML(String urlToRead) {
		try {
			StringBuilder result = new StringBuilder();
			URL url = new URL(urlToRead);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			rd.close();
			return result.toString();
		} catch (IOException e) {
			// Cannot connect to poloniex
			e.printStackTrace();
			return null;
		}
	}

	public static JSONObject getJsonObject(String url) {
		String jsonString = getHTML(url);
		return new JSONObject(jsonString);
	}

	public static JSONArray getJsonArray(String url) {
		String jsonString = getHTML(url);
		JSONArray jArr = new JSONArray(jsonString);
		return jArr;
	}

}

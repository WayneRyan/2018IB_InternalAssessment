

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerDateModel;
import javax.swing.SpringLayout;
public class ParametersPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> exchangeType;
	private Coin[] coinList;
	private JLabel exchangeTypeLabel;
	
	private JList<String> compareCoin;
	private JLabel compareCoinLabel;
	
	private JComboBox<String> resolution;
	private static String[] resolutionList = {"5 min", "15 min", "30 min", "4 hrs", "24 hrs"};
	private JLabel resolutionLabel;
	
	private JSpinner startDate;
	private JLabel startDateLabel;
	
	private JSpinner endDate;
	private JLabel endDateLabel;
	
	private JButton simulate;
	
	private SpringLayout layout;
	
	private Coin coin;
	public ParametersPanel() {
		layout = new SpringLayout();
		this.setLayout(layout);
		this.setBorder(BorderFactory.createTitledBorder("Parameters"));
		
		
		
		exchangeTypeLabel = new JLabel("Coin: ");
		this.add(exchangeTypeLabel);
		
		//Setting up exchange combo box
		String[] coinStrings = Poloniex.getMarkets();
		coinList = new Coin[coinStrings.length];
		
		for(int i = 0; i < coinList.length; i++) {
			String s = coinStrings[i];
			Coin c = new Coin(s);
			coinList[i] = c;
		}	
		exchangeType = new JComboBox<String>(coinStrings);
		this.add(exchangeType);
		
		//Compare to coin
		compareCoinLabel = new JLabel("Compare against: ");
		this.add(compareCoinLabel);
		
		compareCoin = new JList<String>(coinStrings);
		compareCoin.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);;
		compareCoin.setLayoutOrientation(JList.VERTICAL);
		//compareCoin.setVisibleRowCount(-1);
		JScrollPane compareCoinScroller = new JScrollPane(compareCoin);
		
		this.add(compareCoinScroller);
		
		//Resolution field
		resolutionLabel = new JLabel("Resolution: ");
		this.add(resolutionLabel);
		resolution = new JComboBox<String>(resolutionList);
		this.add(resolution);
		
		//Start date
		//TODO: limit start date to current time
		startDateLabel = new JLabel("Start Date: ");
		this.add(startDateLabel);
		startDate = new JSpinner(new SpinnerDateModel());
		Calendar cStart = new GregorianCalendar();
		cStart.setTime(new Date());
		cStart.add(Calendar.DAY_OF_YEAR,-1);	
		startDate.setValue(cStart.getTime());
		this.add(startDate);
		
		//End date
		//TODO: limit end date to current time
		endDateLabel = new JLabel("End Date: ");
		this.add(endDateLabel);
		endDate = new JSpinner(new SpinnerDateModel());
		Calendar cEnd = new GregorianCalendar();
		cEnd.setTime(new Date());
		endDate.setValue(cEnd.getTime());
		this.add(endDate);
		
		//Empty space hot fix
		JPanel empty = new JPanel();
		this.add(empty);
		
		//Simulate button
		simulate = new JButton("Simulate");
		simulate.addActionListener(this);
		this.add(simulate);
		
		
		
		SpringUtilities.makeCompactGrid(this, 6, 2, 6, 6, 6, 6);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

	}

	
	public void addButtonActionListener(ActionListener listener) {
		simulate.addActionListener(listener);
	}
	
	public Coin getSelectedCoin() {
		String name = (String)exchangeType.getSelectedItem();
		Coin c = new Coin(name);
		return c;
	}
	
	public int getResolution() {
		//Get resolution
		int index = resolution.getSelectedIndex();
		int resTime = 0;
		switch (index) {
			case 0:
				resTime = 300; break;
			case 1:
				resTime = 900; break;
			case 2:
				resTime = 1800; break;
			case 3:
				resTime = 14400; break;
			case 4:
				resTime = 86400; break;
		}
		return resTime;
	}
	public Long getStart() {
		Date start = (Date)startDate.getValue();
		return start.getTime()/1000;
	}
	public Long getEnd() {
		Date end = (Date)endDate.getValue();
		return end.getTime()/1000;
	}
	
	public void setButtonEnabled(boolean enabled) {
		simulate.setEnabled(enabled);
	}
	
	public List<String> getCompareCoins(){
		return compareCoin.getSelectedValuesList();
	}
}

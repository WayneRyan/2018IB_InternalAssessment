

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;

public class Main extends JFrame implements ActionListener, Runnable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints c;
	private ParametersPanel p;
	private FunctionPanel f;
	private Chart chart;
	
	private int prog, toDl;
	public Main() {
//		System.setProperty("http.proxyHost", "172.16.0.126");
//		System.setProperty("http.proxyPort", "8080");
//		System.setProperty("https.proxyHost", "172.16.0.126");
//		System.setProperty("https.proxyPort", "8080");
		c = new GridBagConstraints();
		this.setLayout(new GridBagLayout());
		
		
		c.fill = GridBagConstraints.BOTH;
		c.ipadx = 10;
		c.weightx = 0.5;
		c.weighty = 0.5;
		
		c.weightx = 0.8;
		c.weighty = 0.8;
		c.gridx = 0;
		c.gridheight = 2;
		chart = new Chart();
		this.add(chart.getChart(), c);
		
		c.weightx = 0.05;
		c.weighty = 0.05;
		c.gridheight = 1;
		c.gridx = 1;
		f = new FunctionPanel();
		this.add(f, c);
		
		c.weightx = 0.15;
		c.weighty = 0.5;
		c.gridy = 1;
		//c.gridheight = 3;
		p = new ParametersPanel();
		p.addButtonActionListener(this);
		this.add(p, c);
		
		//c.gridheight = 0;
		/*c.gridx = 0;
		c.gridy = 2;
		c.weightx = 0.2;
		c.weighty = 0.1;
		this.add(new StatsPanel(), c);
		*/
		this.setSize(1300, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new Main();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
			new Thread(this).start();
	}

	@Override
	public void run() {
		chart.clearData();
		p.setButtonEnabled(false);
		chart.setTitle("Downloading");
		
		//Get data from coins to compare against
		List<String> coinsString = p.getCompareCoins();
		Coin[] compareCoins = new Coin[coinsString.size()];
		
		toDl = compareCoins.length+1; //Coins to download: Include + 1 for analyze coin
		prog = -1; //# of coins downloaded
		updateChartTitle();
		
		
		//Get data from coin to analyze
		Coin c = p.getSelectedCoin();
		int resolution = p.getResolution();
		long start = p.getStart();
		long end = p.getEnd();
		c.setParameters(resolution, start, end);
		
		updateChartTitle();
		

		
		//Make coin objects from strings
		for (int i = 0; i < coinsString.size(); i++) {
			compareCoins[i] = new Coin(coinsString.get(i));
			compareCoins[i].setParameters(resolution, start, end);
			updateChartTitle();

		}
		
		//Simulator stuff goes here
		
		if (f.getSelectedFile() != null) {
			chart.clearData();
			chart.setTitle("Analyzing...");
			double[] simData;
			long[] simDate;
			try {
				Simulator s = new Simulator(f.getSelectedFile(), c, compareCoins);
				simData = s.getSimData();
				simDate = s.getSimDate();
			} catch (IOException e) {
				chart.setTitle("Error: Sim function");
				e.printStackTrace();
				return;
			} catch (Exception e) {
				chart.setTitle("Internal Error");
				e.printStackTrace();
				return;
			}
			chart.addData(c.getData(), c.getName());
			chart.addPredData(simData, simDate);
		} else {
			chart.setTitle(c.getName());
			chart.addData(c.getData(), c.getName());
		}
		
		
		
		p.setButtonEnabled(true);
		
	}
	
	private void updateChartTitle() {
		//Updates progress of downloaded coins
		chart.clearData();
		prog++;
		String progress = "("+prog+"/"+toDl+")";
		String title = "Downloading... "+progress;
		System.out.println(title);
		chart.setTitle(title);
	}
}


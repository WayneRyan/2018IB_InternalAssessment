import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Date;
import java.util.HashMap;

public class Test {

	public static void main(String[] args) {
		System.setProperty("http.proxyHost", "172.16.0.126");
		System.setProperty("http.proxyPort", "8080");
		System.setProperty("https.proxyHost", "172.16.0.126");
		System.setProperty("https.proxyPort", "8080");
		Date d = new Date();
		int time = (int) (d.getTime() / 1000);
		int time24Hr = time - 86400;
		System.out.println(time);
		
//		Coin[] coins = {new Coin("BTC_ETH"), new Coin("BTC_XRP"), new Coin("BTC_BCH"), new Coin("BTC_DASH")};
//		for (Coin c : coins) 
//			c.setParameters(3, time24Hr, time);
//		ex.export(coins);
		System.out.println("Reading array list from file...");
		Coin[] arr = importFile();
		for (Coin c : arr) {
			System.out.println("Coin name: "+c.getName());
			HashMap<Long, Double> data = c.getData();
			for (Double dub : data.values()) {
				//System.out.println(dub);
			}
		}
		System.out.println("Size "+arr[0].getData().size());
		System.out.println("Start date: "+arr[0].getDates()[0]);
		System.out.println("End date: "+arr[0].getDates()[arr[0].getDates().length-1]);
		System.out.println("Done");
		
		/*
		Poloniex p = new Poloniex();
		String[] markets = p.listMarkets();
		for (int i = 0; i < markets.length; i++) {
			System.out.println(markets[i]);
		}
		System.out.println("Total markets: "+markets.length);
		*/
	}

	public static Coin[] importFile() {
		try {
			FileInputStream fis = new FileInputStream("polo_data.tmp");
			System.out.println();
			ObjectInputStream ois = new ObjectInputStream(fis);
			Coin[] ret = (Coin[])ois.readObject();
			fis.close();
			ois.close();
			return ret;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

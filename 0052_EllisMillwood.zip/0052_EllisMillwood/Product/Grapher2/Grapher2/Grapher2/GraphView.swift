//
//  GraphView.swift
//  Grapher2
//
//  Created by Ellis Millwood on 2/8/18.
//  Copyright © 2018 Ellis Millwood. All rights reserved.
//

import UIKit

class GraphView: UIView {
    
    
//    var points: [Points] = []
    var xValues: Array<Double> = []
    var yValues: Array<Double> = []
    var positions: Array<CGPoint> = []
    
    // let graph = GraphView(frame ...)
    // self.view.addSubView(graph)
    // graph.datasource = self
    // graph.reloadData()
    
    func getData(x: Array<Double>, y: Array<Double>){
        xValues = x
        yValues = y
    }
    
    func reloadData(){
        var pos = 0
        while (pos < xValues.count && pos < yValues.count) {
            positions.append(CGPoint(x: xValues[pos],y: yValues[pos]))
            pos += 1
        }
        
    }
    
    func flip(){
        for i in 0..<yValues.count{
            yValues[i] *= -1
        }
    }
    
    func sort(){
        for i in 0..<xValues.count{
            for j in i..<xValues.count{
                if(xValues[i] > xValues[j]){
                    let xTemp = xValues[i]
                    let yTemp = yValues[i]
                    xValues[i] = xValues[j]
                    yValues[i] = yValues[j]
                    xValues[j] = xTemp
                    yValues[j] = yTemp
                }
            }
        }
    }
    
    func shift(){
        let xShiftDistance = xValues[findMinIndex(arr: xValues)]
        let yShiftDistance = yValues[findMinIndex(arr: yValues)]
        for i in 0..<xValues.count{
            xValues[i] -= xShiftDistance
            yValues[i] -= yShiftDistance
        }
    }
    
    func findMax(arr: Array<Double>) -> Double {
        var max: Double = arr[0]
        for i in 0..<arr.count{
            if(arr[i] > max){
                max = arr[i]
            }
        }
        return max
    }
    
    
    func findMin(arr: Array<Double>) -> Double {
        var min: Double = arr[0]
        for i in 0..<arr.count{
            if(arr[i] < min){
                min = arr[i]
            }
        }
        return min
        
    }
    
    func findMinIndex(arr: Array<Double>) -> Int {
        var index: Int = 0
        var min: Double = arr[0]
        for i in 0..<arr.count {
            if(arr[i] < min){
                min = arr[i]
                index = i
            }
        }
    return index
    }
    
    func scale(){
        if xValues.count > 1{
            let xScale = Double(self.frame.width) / (findMax(arr: xValues) - findMin(arr: xValues))
            let yScale = Double(self.frame.height) / (findMax(arr: yValues) - findMin(arr: yValues))
            for i in 0..<xValues.count {
                xValues[i] *= xScale
                yValues[i] *= yScale
            }
        }
    }
    
    
    
    override func draw(_ rect: CGRect) {
        sort()
        flip()
        shift()
        scale()
        reloadData()
        let context = UIGraphicsGetCurrentContext()
        
        context!.clear(CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
        context!.setFillColor(UIColor.white.cgColor)
        context!.fill(CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
        
        context!.beginPath()
        context!.setStrokeColor(UIColor.blue.cgColor)
        context!.setLineWidth(3.0)
        for i in 0..<positions.count-1 {
            context!.move(to: positions[i])
            context!.addLine(to: positions[i+1])
        }
        context!.strokePath()
        context!.closePath()
        
        context!.beginPath()
        let pointWidth: CGFloat = 6.0
        let pointHeight: CGFloat = 6.0
        context!.setStrokeColor(UIColor.red.cgColor)
        for i in 0..<positions.count {
            context!.addEllipse(in: CGRect(x: positions[i].x - CGFloat(pointWidth/2), y: positions[i].y - CGFloat(pointHeight/2), width: pointWidth, height: pointHeight))
        }
        context!.strokePath()
        context?.closePath()
        
    }
    
}

//
//  ViewController.swift
//  Grapher2
//
//  Created by Ellis Millwood on 1/25/18.
//  Copyright © 2018 Ellis Millwood. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var DataEntry: UITextView!
    var xValues = Array<Double>()
    var yValues = Array<Double>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let EntryText: String = DataEntry.text
        
        let DestViewController : View2 = segue.destination as! View2
    
        DestViewController.LabelText = DataEntry.text
    
        var numberString = Array<String>()

        print(EntryText.count)
    
        var tempString = ""
        var i=0
        var evenOddCheck = 0
    
        for word in EntryText{
            if(word != "," && word != "\n"){
                //add to number string if it is not one of the marking characters
                tempString.append(word)
            }
    
            i+=1
    
            if(word == "," || word == "\n" || EntryText.count == i) {
                //end temporary string & store in numbers then clear temporary string
                evenOddCheck+=1
                numberString.append(tempString)
                tempString = ""
            }
        }
    
        var j=0
        xValues = []
        yValues = []
    
        while j < numberString.count {
//            split values up into x and y
            let doubleFromString = (numberString[j] as NSString).doubleValue
    
//            adding numbers to respective list of x and y from one list
            if(j % 2 == 0){
                xValues.append(doubleFromString)
            }else{
                yValues.append(doubleFromString)
            }
            j+=1
        }
    
        if (j <= 1) {
            xValues = [0]
            yValues = [0]
        }
    
        DestViewController.xVals = xValues
        DestViewController.yVals = yValues
    
        print(i)
        print("number Strings: ",numberString)
        print("xValues: ",xValues)
        print("yValues: ",yValues)
    }
    
}

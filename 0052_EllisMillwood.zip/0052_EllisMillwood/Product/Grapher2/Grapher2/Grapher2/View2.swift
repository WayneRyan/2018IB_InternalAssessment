//
//  GraphView.swift
//  Grapher2
//
//  Created by Ellis Millwood on 2/8/18.
//  Copyright © 2018 Ellis Millwood. All rights reserved.
//

import UIKit

class View2: UIViewController {
    
    var xVals: Array<Double> = []
    var yVals: Array<Double> = []

    @IBOutlet var Graph: GraphView!
    @IBOutlet var Label: UILabel!
    
    var LabelText = String()
    
    override func viewDidLoad() {
        Label.text = LabelText
        self.Graph.getData(x: xVals,y: yVals)
    }

}

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class MainClass {
	
	public static void main(String[] args) throws IOException {
		
		String filePath = ""; // path to input data file
		int[] vals = null; // three number "function format"
		int predCoin = -1; // coin to be predicted  
		int dataCoin = -1; // price of predCoin will be predicted based upon current price of this coin

        try{
        	filePath = args[0];
        	String[] config = args[1].split(",");
        	vals = new int[config.length];
        	for(int i = 0 ; i < config.length ; i++){
        		vals[i] = Integer.parseInt(config[i]);
        	}
        } catch (ArrayIndexOutOfBoundsException e){
        	System.out.println("");
        	System.out.println("Please use the command as so:");
        	System.out.println("java -jar testpred.jar [path of price file] [start date] [end date] [##,##,## prediction config] [prediction coin] [data coin]");
        	System.out.println("");
        	System.exit(0);
        }
		Coin[] arr = readFile(filePath);
		for(int c = 0 ; c < arr.length ; c++){
			if(args[2].equals(arr[c].getName())){
				predCoin = c;
			}

			if(args[3].equals(arr[c].getName())){
				dataCoin = c;
			}
		}
		if(predCoin == -1) {
			System.out.println("Invalid coin symbol for predCoin, please check the coin symbol"); 
			System.exit(dataCoin);
		}
		if(dataCoin == -1) {
			System.out.println("Invalid coin symbol for dataCoin, please check the coin symbol"); System.exit(dataCoin);
			System.exit(predCoin);
		}
		long startDate = Long.parseLong(args[4]);
		long endDate = Long.parseLong(args[5]);
		Long[] dates = arr[0].getDates();
		int[] dateIndexes = dateIndexes(startDate, endDate, arr[0].getDates());
		double[][] prepMatrix = makePrepMatrix(makeValArray(arr), dateIndexes[1], dateIndexes[0]);
		double[] y = makeYVector(prepMatrix,vals,predCoin);
		double[][] x = makeXMatrix(prepMatrix,vals,dataCoin);
		MultipleLinearRegression regression = new MultipleLinearRegression(x, y);
		
		// use coeficients to calculate prediction
		double[] z = new double[4];
		z[0] = 1;
		z[1] = prepMatrix[prepMatrix.length - vals[0]][dataCoin]; 
		z[2] = 1;
		for(int i=prepMatrix.length - vals[1] ; i<prepMatrix.length ; i++){
			z[2] *= prepMatrix[i][dataCoin]; // week
		}
		z[3] = 1;
		for(int i=prepMatrix.length - vals[2] ; i<prepMatrix.length ; i++){
			z[3] *= prepMatrix[i][dataCoin]; // month
		}
		double prediction = 0;
		for(int i=0 ; i<4 ; i++){
			prediction += z[i]*regression.beta(i);
		}
		System.out.println(prediction);
		
		/**    using new methods **/

		
		//END PREP
    		
    }


	public static Coin[] readFile(String filePath) {
		try {
			System.out.println(filePath);
			//InputStream fis = MainClass.class.getResourceAsStream(System.getProperty("user.dir") + "\\" + filePath);
			InputStream fis = MainClass.class.getResourceAsStream(filePath);
			ObjectInputStream ois = new ObjectInputStream(fis);
			Coin[] ret = (Coin[])ois.readObject();
			fis.close();
			ois.close();
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
			return null; // unreachable code to satisfy the compiler
		}
	}
	
	// return price changes as a percentage ( >1 means up ) ( <1 means down )
	// each coin is a row
	// each date is a col with smallest index as most recent
	// row major order
	public static double[][] makeValArray(Coin[] arr){
		double[][] valArr = new double[arr.length][arr[0].getData().size() ];
		Long[] dates = arr[0].getDates();
		int coinIndex = 0;
		for (Coin c : arr) {
			HashMap<Long, Double> data = c.getData();
			for(int i=0 ; i<dates.length ; i++){
				valArr[coinIndex][i] = data.get(dates[i]);
			}
			coinIndex++;
		}
		for(int i = 0 ; i < valArr.length ; i ++){
			valArr[i] = computePercents(valArr[i]);
		}
		return valArr;
	}
	
	// arr is an array of prices smallest index as most recent
	public static double[] computePercents(double[] arr){
		double[] retVal = new double[arr.length - 1];
		for(int i = 0 ; i < retVal.length ; i++){
			retVal[i] = 1 + (arr[i ] - arr[i+1])/arr[i+1];
		}
		return retVal;
	}
	
	
	// arr - each row is a coin each col is a date with smallest index as most recent
	// This method trims the dates of arr and transposes col and row
	// return value = Each row is a date, each column is a coin. The last row has today's data
	
	public static double[][] makePrepMatrix(double[][] arr, int startIndex, int endIndex){
		double[][] prepMatrix = new double[startIndex - endIndex][arr.length];
		for(int coin = 0 ; coin < prepMatrix[0].length ; coin++){
			for(int date = 0 ; date < prepMatrix.length ; date++){
				prepMatrix[date][coin] = arr[coin][date + endIndex];
			}
		}
		return prepMatrix;
	}

	// arr is formatted as output from makePrepMatrix
	// var is describes the predictor function - used to determine size of output array
	public static double[] makeYVector(double [][] arr, int[] var, int coin){
		int max = var[0];
		for(int val : var)if(val>max)max = val;
		double[] y = new double[arr.length-max]; //
		for(int i=0 ; i<y.length ; i++){
			y[i] = arr[i+max][coin];
		}
		return y;
	}

	// arr is formatted as output from makePrepMatrix
	// var is describes the predictor function - used to determine size of output array
	public static double[][] makeXMatrix(double [][] arr, int[] var, int coin){
		int max = var[0];
		for(int val : var)if(val>max)max = val;		
		double[][] x = new double[arr.length-max][var.length+1];
		for(int r=0 ; r<x.length ; r++){
			x[r][0] = 1;
			for(int c=0 ; c<var.length ; c++){
				x[r][c+1] = 1;
				for(int j=0 ; j<var[c] ; j++){
					x[r][c+1] *= arr[r+max-var[c]+j][coin]; 
				}
			}			
		}
		return x;
	}
	
	// dates is an array of valid dates sorted from most recent to oldest
	// return the index values corresponding to the startDate and endDate
	// starIndex is at 0 and endIndex is at 1 
	public static int[] dateIndexes(long startDate, long endDate, Long[] dates){
		int[] dateIndexes = new int[2];
		while(dates[dateIndexes[1]]<endDate)dateIndexes[1]++;
		while(dates[dateIndexes[0]]<startDate)dateIndexes[0]++;
		return dateIndexes;
	}
}


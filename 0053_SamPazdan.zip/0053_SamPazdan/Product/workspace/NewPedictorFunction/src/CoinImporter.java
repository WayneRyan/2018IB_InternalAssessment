import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;

public class CoinImporter {

	public static void main(String[] args) {

		Coin[] arr = importFile();
		for (Coin c : arr) {
			System.out.println("Coin name: "+c.getName());
			HashMap<Long, Double> data = c.getData();
			for (Double dub : data.values()) {
				System.out.println(dub);
			}
		}
		System.out.println("Done");
		
	}

	public static Coin[] importFile() {
		try {
			FileInputStream fis = new FileInputStream("polo_data.tmp");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Coin[] ret = (Coin[])ois.readObject();
			fis.close();
			ois.close();
			return ret;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

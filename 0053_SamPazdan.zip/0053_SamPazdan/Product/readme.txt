datafile1.tmp

Coins: BTC_DASH BTC_EMC2
First Date: 1519607400
Last Date: 1522281000

datafile2.tmp

Coins: BTC_ARDR BTC_BCH
First Date: 1519607400
Last Date: 1522281000

datafile3.tmp

Coins: BTC_BCH BTC_DASH
First Date: 1519607400
Last Date: 

